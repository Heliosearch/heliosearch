/**
 * SIREn's JSON query configuration.
 *
 */
package com.sindicetech.siren.qparser.tree.config;

