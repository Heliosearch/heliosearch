/**
 * DSL for building SIREn's JSON queries.
 *
 */
package com.sindicetech.siren.qparser.tree.dsl;

