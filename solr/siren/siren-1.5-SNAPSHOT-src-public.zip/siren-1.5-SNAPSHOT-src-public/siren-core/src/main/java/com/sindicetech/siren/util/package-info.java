/**
 * This package contains some utility classes.
 *
 */
package com.sindicetech.siren.util;

