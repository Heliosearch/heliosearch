# SIREn Elasticsearch

## Introduction

This module provides a plugin for Elasticsearch to integrate the core functionality and
the query language of SIREn into the Elasticsearch API.

## Module Description

* **src/main/java**

    The source code of the Elasticsearch plugin.

* **src/test/java**

    The source code of the unit tests.

- - -

Copyright (c) 2014, Sindice Limited. All Rights Reserved.