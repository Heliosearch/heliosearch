# SIREn License

SIREn follows a similar licensing model than MongoDB.

The SIREn Core and QParser modules are released under the GNU Affero General Public License, Version 3.0, which is
a copyleft license. This means that if you extend or modify the source code of these modules, you have to contribute 
those modification back to the community. 

The SIREn Solr and Elasticsearch modules are released under the Apache License Version 2.0, which is copyleft free. You
can build client applications which uses the SIREn Solr or Elasticsearch plugin without having to contribute your 
client applications back to the community.