# SIREn Lucene Demo

## Introduction

This module provides a demonstration of the integration of SIREn with Lucene. 

## Module Description

* **src/main/java**

    The source code of the demo.

* **src/datasets**

    The datasets used in the Lucene demo.

- - -

Copyright (c) 2014, Sindice Limited. All Rights Reserved.