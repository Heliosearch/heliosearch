/**
 * A demo based on the British National Bibliography dataset.
 */
package com.sindicetech.siren.demo.bnb;

