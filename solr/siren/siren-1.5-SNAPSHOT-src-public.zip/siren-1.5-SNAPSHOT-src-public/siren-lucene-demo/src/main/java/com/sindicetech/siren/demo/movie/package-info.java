/**
 * A demo based on the Movie dataset from the Web Data Management book.
 */
package com.sindicetech.siren.demo.movie;

