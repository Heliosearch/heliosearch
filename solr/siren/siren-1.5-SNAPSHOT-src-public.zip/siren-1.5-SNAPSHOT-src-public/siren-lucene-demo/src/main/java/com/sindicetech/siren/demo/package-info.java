/**
 * A simple demo of the SIREn Core API.
 */
package com.sindicetech.siren.demo;

